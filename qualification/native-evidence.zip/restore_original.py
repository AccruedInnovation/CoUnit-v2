from scriptengine import *
import os,io,json,traceback
args=json.loads(mcp_input_json)
r={'ok':False,'sections':0}
try:
 p=projects.get_by_path(args['library'])
 def compare(parent,root):
  for name in sorted(os.listdir(root)):
   d=os.path.join(root,name)
   if not os.path.isdir(d):continue
   matches=[x for x in parent.get_children(False) if x.get_name()==name]
   if len(matches)!=1:raise ValueError('Native hierarchy mismatch: '+d)
   obj=matches[0]
   for suffix,attr in [('.DEC.exp','textual_declaration'),('.IMP.exp','textual_implementation')]:
    f=os.path.join(d,name+suffix)
    if os.path.isfile(f):
     with io.open(f,'r',encoding='utf-8-sig') as s:expected=s.read().replace('\r\n','\n')
     if getattr(obj,attr).text.replace('\r\n','\n')!=expected:raise ValueError('Source mismatch: '+f)
     r['sections']+=1
   compare(obj,d)
 compare(p,args['source'])
 r['version']=str(p.get_project_info().version)
 p.close()
 current=projects.primary
 if str(current.path)!=args['qualification']:raise ValueError('Unexpected primary project')
 current.save()
 current.close()
 original=projects.open(args['original'])
 r['restored_primary']=str(original.path)
 r['ok']=r['restored_primary']==args['original']
except Exception:r['exception']=traceback.format_exc()
finally:
 with io.open(args['report'],'w',encoding='utf-8') as f:f.write(unicode(json.dumps(r,indent=2)))
mcp_result=json.dumps(r)
