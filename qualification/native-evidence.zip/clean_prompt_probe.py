from scriptengine import *
import json
old=(system.script_prompt_handling,system.log_prompt_details)
try:
 if not str(projects.primary.path).endswith('CoUnit2\\qualification.project'): raise ValueError('Wrong project')
 system.script_prompt_handling=ScriptPromptHandling.LogPrompts
 system.log_prompt_details=True
 next(c for c in system.commands if str(c.guid)=='024a0dc9-987d-42be-add4-5775c60d128a').execute()
 mcp_result=json.dumps({'returned':True})
finally:
 system.script_prompt_handling,system.log_prompt_details=old
