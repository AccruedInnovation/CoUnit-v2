from scriptengine import *
import json
p=projects.get_by_path(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\counit_2.0.0.library')
t=next(iter(p.find('GVL_coUnit',True))).textual_declaration.text
mcp_result=json.dumps({'cr':t.count('\r'),'lf':t.count('\n'),'check_all':str(getattr(p,'check_all',None)),'build':str(getattr(p,'build',None)),'active':str(p.active_application),'settings':str(p.project_settings.get_compilerversion())})
