from scriptengine import *
import json
cs=list(system.commands)
mcp_result=json.dumps({'sample':[str(x) for x in cs[:3]],'type':dir(cs[0]),'matches':[str(x) for x in cs if any(w in str(x).lower() for w in ['build','clean','check'])]})
