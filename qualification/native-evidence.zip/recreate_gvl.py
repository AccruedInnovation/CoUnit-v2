from scriptengine import *
import json,io
p=projects.get_by_path(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\counit_2.0.0.library')
x=next(iter(p.find('GVL_coUnit',True)))
parent=x.parent
x.remove()
parent.create_gvl('GVL_coUnit')
mcp_result=json.dumps({'recreated':'GVL_coUnit'})
