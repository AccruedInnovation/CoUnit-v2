from scriptengine import *
import json
mcp_result=json.dumps([{'value':str(r),'members':dir(r)} for r in librarymanager.repositories])
