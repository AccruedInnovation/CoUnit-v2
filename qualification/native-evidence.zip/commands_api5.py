from scriptengine import *
import json
mcp_result=json.dumps([{'name':x.name,'id':str(x.guid),'description':x.description} for x in system.commands if any(w in (str(x.name)+' '+str(x.description)).lower() for w in ['rebuild','clean all','check all','build'])])

