from scriptengine import *
import json
mcp_result=json.dumps({'uninstall':str(librarymanager.uninstall_library.__doc__),'file':str(librarymanager.get_file_path.__doc__),'update':str(librarymanager.update_repository.__doc__)})
