from scriptengine import *
import json
p=projects.primary
t=next(x for x in p.get_children(True) if x.is_task)
mcp_result=json.dumps({'add':str(t.pous.add.__doc__)})
