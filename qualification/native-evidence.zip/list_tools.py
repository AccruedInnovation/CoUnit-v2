from CIScripts.mcp_client import Client
import json
c=Client()
r=c.request('tools/list',{})
open('LocalArtifacts/CoUnit2/tools-current.json','w').write(json.dumps(r,indent=2))
for t in r.get('result',{}).get('tools',[]):
 if any(w in t['name'].lower() for w in ['build','command','project']):print(t['name'],str(t.get('inputSchema'))[:1600])
c.close()
