from scriptengine import *
import json,io
p=projects.primary
r={'local': [{'name':x.get_name(),'parent':x.parent.get_name(),'text':x.textual_declaration.text} for x in p.find('GVL_coUnit',True)]}
r['installpath']=str(librarymanager.get_file_path(librarymanager.get_library('coUnit - A unittest framework for CODESYS', '2.0.0.0', 'www.co5e.org')))
with io.open(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\package-local.json','w',encoding='utf-8') as f:f.write(unicode(json.dumps(r,indent=2)))
mcp_result=json.dumps(r)
