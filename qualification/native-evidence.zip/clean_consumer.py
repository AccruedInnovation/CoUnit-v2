from scriptengine import *
import json
cmd=next(c for c in system.commands if str(c.guid)=='024a0dc9-987d-42be-add4-5775c60d128a')
cmd.execute()
mcp_result=json.dumps({'cleaned':str(projects.primary.path)})
