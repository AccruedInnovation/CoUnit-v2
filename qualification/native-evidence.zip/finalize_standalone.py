from pathlib import Path
import csv, hashlib, json, shutil, subprocess, sys, zipfile
repo=Path(r'D:\AI\CodesysNewLib\repo'); art=repo/'LocalArtifacts/CoUnit2'; dst=Path(r'D:\Projects\CoUnit-v2'); q=dst/'qualification'
sys.path.insert(0,str(q))
from check_runtime_matrix import check, STATUSES
from verify_xunit import summarize, require_disposition
restored=json.loads((art/'restoration.json').read_text()); assert restored['ok'] and restored['sections']==599
consumer=json.loads((art/'consumer-native6.json').read_text()); assert consumer['ok'] and consumer['errors']==0 and consumer['completed'] and not consumer.get('cleanup_exception')
s=summarize(art/'reports/consumer-6.xml'); require_disposition(s,success=True)
names=['StartupFill_ReturnsZero','ConstantInput_ProducesExpected','SlidingWindow_CorrectAverage','WindowWrap_CorrectAfterOverwrite','ZeroInput_AfterFill_BringsAverageDown','InitFlag_TrueOnFirstCall_FalseOnSecondCall','NegativeValues_AveragedCorrectly','WarmReset_ResumesWithoutReconfig']
assert [c['name'] for c in s['suites'][0]['cases']]==names and sum(c['assertions'] for c in s['suites'][0]['cases'])==30
for p in (repo/'dependencies/CoUnit/2.0.0/PlaintextExport').rglob('*.exp'):
 assert p.read_bytes()==(dst/'PlaintextExport'/p.relative_to(repo/'dependencies/CoUnit/2.0.0/PlaintextExport')).read_bytes()
assert (dst/'counit_2.0.0.library').read_bytes()==(art/'counit_2.0.0.library').read_bytes()
sha=hashlib.sha256((dst/'counit_2.0.0.library').read_bytes()).hexdigest()
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()+' + CoUnit 2.0.0 working tree'
identity={'version':'2.0.0','native_version':'2.0.0.0','candidate_revision':revision,'candidate_hash':sha,'hash_subject':'counit_2.0.0.library (SHA-256)','source_sections':599,'source_binding':'restoration.json: exact normalized DEC/IMP read-back before closing candidate','environment':'Windows 11 x64 local CODESYS simulator; Windows-1252 STRING compiler mode','accepted_consumer':'consumer-native6.json; reports/consumer-6.xml','qualification_date':'2026-09-10','native_utf8_compiler_row':'UNQUALIFIED'}
(q/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
mapping={
1:'suites_max-run2.json;suites_overflow-run2.json',2:'tests_max-run2.json;tests_overflow-run2.json',3:'assertions_max-run2.json;assertions_overflow-run3.json',4:'zero-run1.json;multiscan-run2.json;suites_max-run2.json',5:'sequence-run2.json;lifecycle-trace2.json;aggregate_65536-run2.json',6:'ordered-run2.json;lifecycle-trace2.json',7:'names-run2.json',8:'multiscan-run2.json',9:'families-run3.json',10:'values-run2.json',11:'values-run2.json',12:'values-run2.json;descriptors-special1.json',13:'values-run2.json',14:'multiscan-run2.json',15:'aggregate_65536-run2.json;aggregate_65536_failed-run3.json;publication-normal-3-check.json;abort-run2.json',16:'multiscan-run2.json;aggregate_65536-run2.json',17:'device-log-native5.json;device-log-capture.json',18:'verbosity-pair-check.json',19:'utf8_diagnostic-special1.json;utf8-diagnostic-capture.json;edge-cp1252-1/run-evidence.json;edge-utf8-1/run-evidence.json',20:'publication-normal-3-check.json;aggregate_65536-run2.json',21:'publication-write-2-check.json;publication-flush-not-supported-2-check.json;publication-flush-not-implemented-2-check.json',22:'cross_task-run3.json',23:'consumer-native6.json;reports/consumer-6.xml',24:'final-source-build.json',25:'host-environment.json;probe.json;aggregate_65536-run2.json',26:'mode_switch-run2.json',27:'initial_lookup-observed1.json;task_lookup-run2.json;platform_helpers-special1.json',28:'names-log-True.json;names-run2.json',29:'abort-run2.json;mode_switch-run2.json;snapshot_failure-observed1.json;seal_violation-observed1.json',30:'lifecycle-hold1.json;lifecycle-reset1.json',31:'edge-pause6-1/recovered-complete-evidence.json;edge-pause7-1/recovered-complete-evidence.json;edge-pause8-1/recovered-complete-evidence.json',32:'multiscan-run2.json'}
scenarios={1:'integrated-run2.json',2:'ordered-run2.json',3:'lifecycle-trace2.json',4:'publication-write-2-check.json',5:'multiscan-run2.json',6:mapping[31],7:'lifecycle-hold1.json;lifecycle-reset1.json',8:'suites_overflow-run2.json;tests_overflow-run2.json;assertions_overflow-run3.json;cross_task-run3.json'}
rows=list(csv.DictReader((q/'coverage.csv').open(newline='',encoding='utf-8')))
for r in rows:
 evid=(scenarios if r['id'].startswith('SCN') else mapping)[int(r['id'].split('-')[-1])]
 for f in evid.split(';'):assert (art/f).is_file(),f
 r['status']='PASS';r['remaining_native_observation']='None for qualified Windows-1252 simulator row';r['evidence_in_native_archive']=evid
with (q/'coverage.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
base={'row_id':'windows-x64-simulator-cp1252','candidate_revision':revision,'candidate_hash':sha,'codesys_dev_system_version':'3.5.22.20','compiler_version':'3.5.19.70','runtime_controller':'CODESYS SimulationRts 3.5.22.20','os_arch':'Windows 11 Enterprise 10.0.26100 x64; AMD Ryzen 9 5900XT','sysfile_version':'3.5.15.0','cmpiectask_version':'3.5.19.0','cmplog_version':'3.5.20.30 (observer-only LogCopyInfo: 3.5.21.0)','project_or_fixture':'qualification/generated; qualification/consumer/consumer.xml','evidence_path':'qualification/native-evidence.zip','string_encoding_mode':'LEGACY_SINGLE_BYTE','legacy_mapping_id':'Windows-1252','snapshot_size_bytes':'84287900','application_static_memory_bytes':'206946402','support_disposition':'SUPPORTED'}
base.update({k:'PASS' for k in STATUSES})
utf=dict(base,row_id='windows-x64-simulator-native-utf8',string_encoding_mode='UTF8',legacy_mapping_id='N/A',support_disposition='UNQUALIFIED');utf.update({k:'NOT_RUN' for k in STATUSES})
with (q/'runtime-matrix.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(base));w.writeheader();w.writerows([base,utf])
assert not check([base,utf]),check([base,utf])
readme=dst/'CoUnit-README.md'; text=readme.read_text(encoding='utf-8-sig')
text=text.replace('# CoUnit v2.0\n','# CoUnit v2.0.0\n',1)
start=text.index('> **Status:**');end=text.index('\n\n',start)
text=text[:start]+'> **Status:** implemented and qualified on the Windows-1252 Windows x64 local simulator configuration recorded in [qualification/runtime-matrix.csv](qualification/runtime-matrix.csv). The packaged library is native version **2.0.0.0**. Other targets and native UTF-8 compiler configurations remain unqualified.'+text[end:]
text=text.replace('CoUnit v2.0 starts from the original **CoUnit 1.2.0** source base.','CoUnit v2.0 starts from the locally patched **CoUnit 1.2.0.3** library, derived from the original CoUnit 1.2.0 source base. The unmodified plaintext baseline is retained in `compatibility/1.2.0.3/`.')
start=text.index('## Current status');end=text.index('## License and attribution',start)
text=text[:start]+'''## Installation and distribution

Install [counit_2.0.0.library](counit_2.0.0.library) through CODESYS Library Repository, then reference **coUnit - A unittest framework for CODESYS, 2.0.0.0 (www.co5e.org)** under namespace `CoUnit`. Disable **Qualified access only** on the reference when existing tests call unqualified `TEST()` and `TEST_FINISHED()`.

Instantiate the suite containers in the test program and call exactly one `CoUnit.RUN()` or `CoUnit.RUN_IN_SEQUENCE()` cyclically. The runner invokes registered suite bodies; do not separately call those bodies. Bind a fresh run-owned `CoUnit.GVL_coUnit.xUnitFilePath` before the first runner call. Use a relative writable runtime path, for example `CoUnit2/run-001.xml`, on the qualified simulator.

| Included path | Purpose |
| --- | --- |
| `counit_2.0.0.library` | Installable native library, with project settings and dependency references |
| `PlaintextExport/` | All 599 inspectable declaration/implementation sections |
| `generate_assertions.py`, `tools/`, `_tools/` | Assertion generation, native synchronization and qualification launch tools |
| `qualification/` | Fixtures, independent report oracles, coverage, exact runtime matrix and native evidence archive |
| `compatibility/1.2.0.3/` | Original plaintext compatibility baseline |
| `docs/CoUnit-PRD-Suite-R3/` | Supplied PRDs and contracts, preserved as received |
| `LICENSE` | Upstream MIT license and attribution |

The historical PRD packet's CANDIDATE/NOT_READY and NOT_RUN authoring labels are preserved as received. Current release outcomes are in `qualification/coverage.csv` and `qualification/runtime-matrix.csv`.

### Migration details

`ST_TestSuiteResults.NumberOfTestCases`, `NumberOfSuccessfulTestCases`, and `NumberOfFailedTestCases` are now **UDINT**, allowing all 65,536 configured tests. This changes the structure's binary layout; rebuild dependent applications and review any external binary mappings.

Every v2 report contains `counit-run-disposition`. Require `NORMAL` as well as correct inventory, fresh publication, and zero testcase failures/errors. A completed publication (`WRITTEN`) alone does not mean the run passed. Generic JUnit consumers may ignore this attribute; gate their input with:

```powershell
python qualification/verify_xunit.py path/to/fresh-report.xml --require-success
```

That command checks XML semantics and run disposition; the launcher must additionally bind freshness and the expected selected inventory. See [REPORTING.md](REPORTING.md). Legacy 1.x host runners are not automatically qualified for v2.

### Qualified results and limits

Qualification covered all 32 VER requirements and eight integrated scenarios on the exact Windows-1252 simulator row. It includes all 44 assertion families, 10,000-invocation behavior, capacity rejection guards, complete 65,536-pass and 65,536-failure inventories, task ownership, abort/restart, ordered and delayed sequence execution, actual Device Log byte capture, 17 publication fault/recovery cases, and 29 publisher edge cases. Expected failing assertions and injected failures are qualification stimuli, not passing product tests.

The saved, installed library compiled an unchanged downstream moving-average suite with **zero errors** and one existing UINT-to-INT warning in that consumer. All **8 tests / 30 assertions passed**, with NORMAL disposition and no skips. Source-import library qualification builds were zero-error and zero-warning. The original CODESYS project was restored after testing.

The default 32-suite / 2,048-test-per-suite configuration has a **84,287,900-byte snapshot**. The full-capacity passing application used **206,946,402 bytes of global data**; allocate sufficient memory for the complete application. The measured simulator row had roughly 62 MB remaining in its configured data area. This does not establish a small-controller memory budget or task-deadline guarantee.

The qualified native compiler STRING mode is **Windows-1252**, not native UTF-8. Raw UTF-8 decoding, boundary truncation and XML conversion were exercised separately; they do not qualify a native UTF-8 project. Absolute filesystem paths were denied by this simulator, and very long expanded filesystem paths hit Windows limits. The 244-byte report-path / 255-byte companion-path contract passed exact byte and no-side-effect boundary checks; it does not promise every operating system can open such a path.

Native versions: CODESYS and simulator 3.5.22.20, compiler 3.5.19.70, SysFile 3.5.15.0, CmpIecTask 3.5.19.0, CmpLog 3.5.20.30. Actual resolved Device Log capture used a temporary test-only CmpLog 3.5.21.0 dependency; it is not a shipping dependency change. No physical controller was exercised.

### Development checks

Python 3.13, standard library only:

```powershell
python generate_assertions.py --check
python qualification/check_public_api.py
python -m unittest discover -s qualification -p test_host_tools.py
python qualification/generate_native.py
python qualification/check_runtime_matrix.py qualification/runtime-matrix.csv
```

Native tooling requires CODESYS, the MCP ScriptRunner extension, matching compiler/libraries and a disposable simulator project. Set `CODESYS_MCP_BRIDGE` if the bridge executable differs from the documented workstation default. See [qualification/README.md](qualification/README.md). Native editing tools require explicit paths; a saved-library consumer build is mandatory because matching source text alone cannot detect stale native language-model data.

''' + text[end:]
text=text.replace('The original CoUnit source base is licensed under the **MIT License**.','The original CoUnit source base is licensed under the **MIT License**, included in [LICENSE](LICENSE) from the [upstream v1.2.0.0 distribution](https://forge.codesys.com/lib/counit/code/HEAD/tree/tags/v1.2.0.0/license.txt?format=raw).')
readme.write_text(text,encoding='utf-8')
p=q/'README.md';text=p.read_text();text=text.replace('These are source fixtures and independent host oracles, **not passing native evidence**. All native outcomes remain `NOT_RUN` until the exact imported candidate is compiled and executed. Only the authorized SP22 Patch2 local Windows simulator is in scope. The original 1.2.0.3 tree remains the compatibility baseline.','These fixtures and independent host oracles have been executed on the exact Windows-1252 SP22 Patch2 local simulator row in `runtime-matrix.csv`. All 32 VER and eight SCN requirements passed for that row; native UTF-8 compiler and physical-controller rows remain unqualified. `native-evidence.zip` preserves accepted runs and earlier failed attempts. `coverage.csv` names the evidence for each requirement. The original 1.2.0.3 tree remains the compatibility baseline.')
text=text.replace('dependencies/CoUnit/2.0.0/','').replace('python validate_generated_code.py','python generate_assertions.py --check')
text+='''\n## Standalone native environment and packaging\n\nThe repository contains the required source generators and MCP bridge client; CODESYS and its licensed extensions are external prerequisites. Create a disposable project with a simulation-capable device and `Application`, save it as `LocalArtifacts/CoUnit2/qualification.project`, and make it primary before running the native launch tools. The tools reject other project names and verify the simulator build before login. The large workstation project and vendor-managed libraries are intentionally not redistributed. `tools/run_native.py` accepts a ScriptEngine file and an explicit JSON argument file; `tools/native_qualification.py` documents the supported operations in its source. Source fixtures can instead be imported manually into an equivalent disposable simulator application. Do not import qualification hooks into the shipped library.\n\nPass `source`, `tools` and `dependency_template` (a secondary copy of the packaged library) for source qualification, plus the chosen XML, report path, finite polling limit and observation variables. `run_shards.py`, `run_publication.py` and `run_publisher_edges.py` encode the tested selections and oracles. Use unique report names; no prior XML is admissible as a new run result.\n\n`native_qualification.py` scopes `LogPrompts`, prompt detail logging and explicit Yes answers to its authorized disposable-project operation, then restores them. Verified keys include `CleanAll_Query`, `CleanActiveApplication_Query`, `QueryProgramChanged` and `QueryCreateApplication`. Unknown prompts use the logged native default rather than opening a blocking modal dialog; inspect their results.\n\nThe first installed-library builds exposed stale native language-model declarations despite exact text read-back. A clean consumer rebuild removed stale method diagnostics; recreating the isolated candidate's GVL_coUnit object and resynchronizing its exact declaration removed the remaining declaration corruption. The final saved library passes installed consumer compilation and all eight tests. `consumer-native1` through `consumer-native5` preserve failures; `consumer-native6` is the accepted run.\n\nThe archive retains original absolute launch paths as evidence, not as active source dependencies. Current generators work from this standalone repository. The archived original-project restoration receipt also records a final 599-section source comparison.\n'''
p.write_text(text,encoding='utf-8')
p=dst/'REPORTING.md';text=p.read_text().replace("The repository's `CIScripts/ci_receipt.py` and `parse_xunit.py`", "The originating process-library repository's `CIScripts/ci_receipt.py` and `parse_xunit.py`");text+='\nThis standalone distribution uses `qualification/verify_xunit.py --require-success` as its v2-specific gate. The originating repository adapters remain there and are not dependencies of this distribution.\n';p.write_text(text,encoding='utf-8')
# Preserve runtime reports that special-case capture did not copy earlier.
runtime=Path.home()/'AppData/Roaming/CODESYS/Simulation/PlcLogic/CoUnit2'
for p in runtime.glob('*.xml'):
 out=art/'reports'/p.name
 if not out.exists():shutil.copy2(p,out)
shutil.copy2(art/'final-validation.txt',q/'originating-repository-validation.txt')
with zipfile.ZipFile(q/'native-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(art.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=p.relative_to(art)
  if p.suffix.lower() in {'.json','.xml','.txt','.py'} or (len(rel.parts)>1 and any(part.endswith('-files') for part in rel.parts)):
   z.write(p,rel.as_posix())
assert len(rows)==40
print('PASS: final release documentation, 40 coverage rows, runtime matrix, required candidate identity and evidence archive')
