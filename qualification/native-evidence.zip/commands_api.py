from scriptengine import *
import json
mcp_result=json.dumps({'system':dir(system),'commands':str(getattr(system,'get_all_commands',None)),'projects':dir(projects)})
