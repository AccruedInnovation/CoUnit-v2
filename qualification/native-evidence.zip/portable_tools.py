from pathlib import Path
v=Path('dependencies/CoUnit/2.0.0')
changes={
'generate_assertions.py': [('REPO = HERE.parents[2]', "REPO = HERE if (HERE / 'docs').is_dir() else HERE.parents[2]"), ('OLD = HERE.parent / "1.2.0.3/PlaintextExport"', 'OLD = (HERE / "compatibility/1.2.0.3/PlaintextExport") if (HERE / "compatibility").is_dir() else HERE.parent / "1.2.0.3/PlaintextExport"')],
'qualification/generate_native.py':[('REPO = HERE.parents[3]', "REPO = HERE.parent if (HERE.parent / 'docs').is_dir() else HERE.parents[3]")],
'qualification/check_public_api.py':[('REPO = HERE.parents[3]', "REPO = HERE.parent if (HERE.parent / 'docs').is_dir() else HERE.parents[3]"), ("BASELINE = HERE.parents[1] / '1.2.0.3/PlaintextExport/Unit Test Framework for CODESYS'", "BASELINE = (REPO / 'compatibility/1.2.0.3' if (REPO / 'compatibility').is_dir() else HERE.parents[1] / '1.2.0.3') / 'PlaintextExport/Unit Test Framework for CODESYS'")],
'qualification/lifecycle_trace/generate.py':[('REPO = HERE.parents[4]', "REPO = HERE.parents[1] if (HERE.parents[1] / 'docs').is_dir() else HERE.parents[4]")],
'qualification/log_capture/generate.py':[("sys.path.insert(0, str(HERE.parents[4] / '_tools'))", "REPO = HERE.parents[1] if (HERE.parents[1] / 'docs').is_dir() else HERE.parents[4]\nsys.path.insert(0, str(REPO / '_tools'))")],
 'tools/run_native.py': [('REPO = Path(__file__).resolve().parents[4]', "VERSION = Path(__file__).resolve().parents[1]\nREPO = VERSION if (VERSION / 'CIScripts').is_dir() else VERSION.parents[2]")]
}
for f in ['tools/run_shards.py','tools/run_publication.py','tools/run_publisher_edges.py']:
 changes[f]=[("ROOT = Path(__file__).resolve().parents[4]\nVERSION = ROOT / 'dependencies/CoUnit/2.0.0'", "VERSION = Path(__file__).resolve().parents[1]\nROOT = VERSION if (VERSION / 'CIScripts').is_dir() else VERSION.parents[2]")]
for name,replacements in changes.items():
 p=v/name;s=p.read_text(encoding='utf-8')
 for old,new in replacements:
  assert old in s,(name,old)
  s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')
