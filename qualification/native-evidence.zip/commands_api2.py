from scriptengine import *
import json
mcp_result=json.dumps({'members':dir(system.commands),'value':str(system.commands)})
