from scriptengine import *
import json
mcp_result=json.dumps({'project':str(projects.primary.path),'prompt_handling':str(system.script_prompt_handling),'prompt_details':system.log_prompt_details})
