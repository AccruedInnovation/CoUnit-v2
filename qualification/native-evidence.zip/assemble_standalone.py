from pathlib import Path
import shutil
src=Path(r'D:\AI\CodesysNewLib\repo'); v=src/'dependencies/CoUnit/2.0.0'; dst=Path(r'D:\Projects\CoUnit-v2')
assert dst.resolve()==Path(r'D:\Projects\CoUnit-v2') and not (dst/'.git').exists()
ignore=shutil.ignore_patterns('__pycache__','*.pyc','validation.txt')
for p in v.iterdir():
 if p.name=='__pycache__':continue
 if p.is_dir():shutil.copytree(p,dst/p.name,ignore=ignore,dirs_exist_ok=True)
 else:shutil.copy2(p,dst/p.name)
shutil.copytree(src/'dependencies/CoUnit/1.2.0.3/PlaintextExport',dst/'compatibility/1.2.0.3/PlaintextExport',ignore=ignore,dirs_exist_ok=True)
shutil.copytree(src/'docs/CoUnit-PRD-Suite-R3',dst/'docs/CoUnit-PRD-Suite-R3',ignore=ignore,dirs_exist_ok=True)
for relative in ['CIScripts/mcp_client.py','_tools/generate_plcopenxml.py']:
 p=dst/relative;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/relative,p)
shutil.copy2(src/'LocalArtifacts/CoUnit2/counit_2.0.0.library',dst/'counit_2.0.0.library')
shutil.copy2(src/'LocalArtifacts/CoUnit2/LICENSE',dst/'LICENSE')
consumer=dst/'qualification/consumer';consumer.mkdir(exist_ok=True)
shutil.copy2(src/'LocalArtifacts/CoUnit2/consumer.xml',consumer/'consumer.xml')
for n in ['M.TestLog.DEC.exp','M.TestLog.IMP.exp']:shutil.copy2(src/'PlaintextExport/Tests/PRG_TEST'/n,consumer/n)
(dst/'.gitignore').write_text('__pycache__/\n*.py[cod]\nLocalArtifacts/\n*.library~\n*.project~\n*.opt\n',encoding='utf-8')
(dst/'.gitattributes').write_text('*.library binary\n*.zip binary\n*.exp text eol=lf\n*.py text eol=lf\n*.md text eol=lf\n*.csv text eol=lf\n',encoding='utf-8')
(dst/'README.md').write_text('# CoUnit v2.0.0\n\nSee [CoUnit-README.md](CoUnit-README.md) for installation, compatibility, qualification and distribution contents.\n',encoding='utf-8')
(dst/'PlaintextExport/README.md').write_text('# CoUnit 2.0.0 source\n\nThe 599 declaration/implementation sections in this tree are the canonical inspectable source for the accompanying `counit_2.0.0.library` (native version 2.0.0.0). Object hierarchy and child methods/properties are preserved. The packaged library also retains native project information, compiler settings and library references.\n\nUse `tools/import_candidate.py` with explicit source, target, tools and report paths to update an isolated library copy. Never direct a whole-tree export into another project\'s source directory. Read-back compares declarations and implementations; final validation must also install the saved library and compile a consumer, because source equality alone does not detect stale native language models.\n',encoding='utf-8')
(dst/'qualification/consumer/README.md').write_text('# Unchanged consumer compatibility\n\n`consumer.xml` packages the original FB_MovingAverage and FB_MovingAverage_Test from the process-library repository without product/test-source edits. The runner invokes only CoUnit.RUN(), provides the existing PRG_TEST.TestLog method, and waits for publication. Library reference `qualified_only` must be FALSE because existing tests use unqualified TEST/TEST_FINISHED.\n\nThe installed 2.0.0.0 library compiled with zero errors and one existing UINT-to-INT warning in FB_MovingAverage. All eight cases passed, 30 assertions, NORMAL disposition, no skips. Native evidence: consumer-native6.json and reports/consumer-6.xml in ../native-evidence.zip.\n',encoding='utf-8')
print('Standalone content copied; original source retained until destination checks complete.')
