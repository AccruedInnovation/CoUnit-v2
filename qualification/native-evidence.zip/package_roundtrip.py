from scriptengine import *
import json, io
p = projects.get_by_path(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\counit_2.0.0.library')
r = {'before': next(iter(p.find('GVL_coUnit', True))).textual_declaration.text}
p.close()
p = projects.open(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\counit_2.0.0.library', primary=False)
r['after'] = next(iter(p.find('GVL_coUnit', True))).textual_declaration.text
with io.open(r'D:\AI\CodesysNewLib\repo\LocalArtifacts\CoUnit2\package-roundtrip.json','w',encoding='utf-8') as f: f.write(unicode(json.dumps(r,indent=2)))
mcp_result = json.dumps(r)
