from scriptengine import *
import json
mcp_result=json.dumps([str(lib) for lib in librarymanager.get_all_libraries() if lib.title=='CmpLog'])
