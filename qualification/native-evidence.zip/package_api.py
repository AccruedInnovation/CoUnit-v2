from scriptengine import *
import json
mcp_result=json.dumps({'librarymanager':dir(librarymanager), 'project':dir(projects.primary), 'manager':dir(projects.primary.active_application.get_library_manager())})
