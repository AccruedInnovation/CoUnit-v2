from scriptengine import *
import json,io
p=projects.primary
p.save()
path=str(p.path)
p.close()
p=projects.open(path)
mcp_result=json.dumps({'path':str(p.path),'reopened':True})
