from scriptengine import *
import json
r=next(r for r in projects.primary.get_library_manager().references if r.name=='#CmpLog')
mcp_result=json.dumps({'members':dir(r),'resolution':str(r.default_resolution)})
